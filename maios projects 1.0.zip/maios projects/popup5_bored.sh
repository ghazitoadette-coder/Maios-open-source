#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - POP-UP KELIMA ENGINE
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/bored_flashbang_twrp.prop"

echo "=========================================="
echo "    ❓ POP-UP KELIMA: UJIAN KESABARAN ❓  "
echo "=========================================="
echo "Apakah Anda sudah bosan dengan ini?"
echo "1. Masih bisa"
echo "2. Aku sudah bosan"
read choice

if [ "$choice" -eq 1 ]; then
    echo ""
    echo "[🎉] KESABARAN TINGKAT DEWA!"
    echo "✅ Semua pop-up jebakan dihentikan secara permanen!"
    echo "🚀 PERFORMA HP KEMBALI NORMAL & FULL UNLOCKED!"
    exit 0

elif [ "$choice" -eq 2 ]; then
    echo ""
    echo "[💀] KAMU MEMILIH: 'Aku sudah bosan'"
    echo "💥 FACTORY RESET EXECUTED! SEMUA DATA HILANG!"
    sleep 1
    echo "⚡ FLASHBANG! LAYAR PUTIH BRIGHTNESS MAX 100%!"
    sleep 1
    echo "🌀 TERJEBAK DI TWRP: NO CUSTOM ROM SUPPORTED!"
    
    # Membaca link TWRP dari file .prop
    TWRP_LINK=$(grep "ro.maios.twrp.link=" "$PROP_FILE" | cut -d'=' -f2)
    echo "🔗 Download Official TWRP: $TWRP_LINK"
    # reboot recovery

else
    echo "[!] Pilihan tidak valid!"
fi
