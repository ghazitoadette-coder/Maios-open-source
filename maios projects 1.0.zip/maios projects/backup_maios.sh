#!/system/bin/sh

SOURCE_DIR="/mnt/sdcard/MaiOS"
BACKUP_DIR="/mnt/sdcard/MaiOS_Backup"

echo "=========================================="
echo "      MAIOS MURASAKI - AUTO BACKUP        "
echo "=========================================="
echo "[INFO] Memulai proses backup..."

# 1. Buat folder backup jika belum ada
mkdir -p "$BACKUP_DIR"

# 2. Salin seluruh isi folder MaiOS ke MaiOS_Backup
cp -r "$SOURCE_DIR/"* "$BACKUP_DIR/"

# 3. Verifikasi status backup
if [ $? -eq 0 ]; then
    echo "[OK] Seluruh file berhasil dicadangkan!"
    echo "[OK] Lokasi Backup: $BACKUP_DIR"
    echo "=========================================="
    echo "[SUCCESS] Backup Selesai!"
else
    echo "[ERROR] Gagal melakukan backup file!"
    echo "=========================================="
fi
