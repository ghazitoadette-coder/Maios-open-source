import os

print("==================================================")
print("   MAIOS MURASAKI EDITION - INSTALLER & PERMISSION")
print("==================================================")

# 1. Simulasi Setup Lingkungan Bootloader / System Root di VM
print("[*] Menyiapkan lingkungan sistem di Virtual Machine...")
target_dirs = [
    "system/etc/init",
    "data/system",
    "vendor/etc"
]

for d in target_dirs:
    os.makedirs(d, exist_ok=True)
    print(f"[+] Direktori sistem disiapkan: /{d}")

# 2. Daftar file MaiOS yang akan di-install dan di-set permission-nya
files_to_install = [
    "config.json",
    "build.prop",
    "init.maios.desktop.rc"
]

print("\n[*] Menerapkan izin file (Permission 644) untuk keamanan sistem...")

for file_name in files_to_install:
    # Buat file dummy jika belum ada untuk simulasi
    if not os.path.exists(file_name):
        with open(file_name, "w") as f:
            f.write(f"# MaiOS Murasaki Edition - {file_name}\n")
    
    # Ubah permission file menjadi 644 (Owner: rw, Group/Others: r)
    try:
        os.chmod(file_name, 0o644)
        print(f"[✔] Sukses set permission 644 -> {file_name}")
    except Exception as e:
        print(f"[!] Gagal set permission untuk {file_name}: {e}")

print("==================================================")
print("[✔] INSTALASI MAIOS SELESAI! Siap di-deploy di VM.")
print("==================================================")
