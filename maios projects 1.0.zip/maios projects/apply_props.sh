#!/system/bin/sh
# ==========================================
# MAIOS PROP INJECTOR SCRIPT
# ==========================================

PROP_DIR="/storage/emulated/0/MaiOS"

echo "[+] Memulai injeksi properti MaiOS Murasaki..."

# Injeksi nav.prop
if [ -f "$PROP_DIR/nav.prop" ]; then
    echo "[+] Menautkan nav.prop..."
    resetprop -n --file "$PROP_DIR/nav.prop"
fi

# Injeksi maios.prop
if [ -f "$PROP_DIR/maios.prop" ]; then
    echo "[+] Menautkan maios.prop..."
    resetprop -n --file "$PROP_DIR/maios.prop"
fi

# Injeksi system.prop
if [ -f "$PROP_DIR/system.prop" ]; then
    echo "[+] Menautkan system.prop..."
    resetprop -n --file "$PROP_DIR/system.prop"
fi

echo "[✓] Semua properti MaiOS Murasaki berhasil diinjeksikan!"
