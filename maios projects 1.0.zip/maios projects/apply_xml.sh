#!/system/bin/sh
# ==========================================================
#   MAIOS MURASAKI EDITION: APPLY XML DATA & THEME
#   Developer: TRG | Theme: Kasane Teto (Murasaki / GreeN 2012)
# ==========================================================

TARGET_DIR="/storage/emulated/0/MaiOS"
LOG_FILE="$TARGET_DIR/system.log"

echo "=================================================="
echo "      MAIOS XML APPLY ENGINE (TRG CORE)           "
echo "=================================================="

# 1. Pastikan folder tujuan tersedia
mkdir -p "$TARGET_DIR"

# 2. Salin & Terapkan Semua File XML
echo "[+] Applying XML layouts and configuration data..."
cp -f *.xml "$TARGET_DIR/" 2>/dev/null

# 3. Setel Izin Akses Penuh (Read & Write)
echo "[+] Setting permissions for XML resources..."
chmod 666 "$TARGET_DIR"/*.xml 2>/dev/null

# 4. Catat Log Sistem
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
echo "[$TIMESTAMP] [XML_APPLIER] All XML layout files successfully installed." >> "$LOG_FILE"

echo "--------------------------------------------------"
echo " [SUCCESS] XML configuration applied to $TARGET_DIR"
echo "=================================================="
