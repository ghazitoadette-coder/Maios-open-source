#!/system/bin/sh
# ==========================================================
#   MAIOS MURASAKI EDITION: STANDALONE ZIP INSTALLER
#   Developer: TRG | Theme: Kasane Teto (Murasaki / GreeN 2012)
# ==========================================================

TARGET_DIR="/storage/emulated/0/MaiOS"
LOG_FILE="$TARGET_DIR/system.log"

echo "=================================================="
echo "    STARTING MAIOS SYSTEM INSTALLER (TRG CORE)    "
echo "=================================================="

# 1. Pastikan folder direktori /MaiOS/ sudah dibuat
if [ ! -d "$TARGET_DIR" ]; then
    echo "[+] Creating directory: $TARGET_DIR"
    mkdir -p "$TARGET_DIR"
fi

# 2. Setel izin penuh & siapkan sistem
echo "[+] Configuring system rules & execution privileges..."
chmod -R 777 "$TARGET_DIR" 2>/dev/null

# 3. Catat status eksekusi ke system.log
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
echo "[$TIMESTAMP] [INSTALLER] install.sh executed successfully from ZIP." >> "$LOG_FILE"

echo "--------------------------------------------------"
echo " [SUCCESS] MaiOS Core System Initialized!"
echo " Location: $TARGET_DIR"
echo "=================================================="
