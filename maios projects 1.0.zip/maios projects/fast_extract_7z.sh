#!/system/bin/sh
# ==========================================================
#   MAIOS MURASAKI EDITION: FAST 7Z EXTRACTOR
#   Developer: TRG | Theme: Kasane Teto (Murasaki / GreeN 2012)
# ==========================================================

TARGET_DIR="/storage/emulated/0/MaiOS"
ARCHIVE_NAME="MaiOS_Data_XML.7z"

echo "=================================================="
echo "    MAIOS FAST 7Z EXTRACTOR ENGINE (TRG CORE)     "
echo "=================================================="

# 1. Pastikan folder tujuan ada
mkdir -p "$TARGET_DIR"

# 2. Proses Ekstraksi Kilat 7z (Multi-Threading)
echo "[+] Unpacking $ARCHIVE_NAME using 7-Zip engine..."

if command -v 7za >/dev/null 2>&1; then
    7za x "$ARCHIVE_NAME" -o"$TARGET_DIR" -y -mmt=on >/dev/null 2>&1
elif command -v 7z >/dev/null 2>&1; then
    7z x "$ARCHIVE_NAME" -o"$TARGET_DIR" -y -mmt=on >/dev/null 2>&1
else
    # Fallback jika binary 7z bawaan dipanggil
    tar -xf "$ARCHIVE_NAME" -C "$TARGET_DIR" 2>/dev/null
fi

# 3. Setel Izin Akses Penuh
chmod -R 777 "$TARGET_DIR" 2>/dev/null

# 4. Otomatis Jalankan apply_xml.sh Jika Tersedia
if [ -f "$TARGET_DIR/apply_xml.sh" ]; then
    echo "[+] Running apply_xml.sh..."
    sh "$TARGET_DIR/apply_xml.sh"
fi

echo "--------------------------------------------------"
echo " [SUCCESS] Fast 7z Extraction Complete!"
echo " Output Location: $TARGET_DIR"
echo "=================================================="
