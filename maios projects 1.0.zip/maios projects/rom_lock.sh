#!/system/bin/sh
# ==========================================
# MAIOS - TWRP ROM INCOMPATIBILITY LOCK
# ==========================================

echo "=========================================="
echo "    ⚠️ TWRP RECOVERY: FLASHING ROM... ⚠️  "
echo "=========================================="
echo "[📂] Memilih file ZIP Custom ROM..."
sleep 1
echo "[⚡] Memulai proses flashing di TWRP..."
sleep 1

echo "❌ ERROR: Error executing updater binary in zip"
echo "❌ Error flashing zip 'Custom_ROM_Final.zip'"
echo "💀 KUTUKAN MAIOS AKTIF: TIDAK ADA SATUPUN CUSTOM ROM DI DUNIA INI YANG SUPPORT!"
echo "🌀 Perangkat terkunci selamanya di dalam TWRP Recovery."
