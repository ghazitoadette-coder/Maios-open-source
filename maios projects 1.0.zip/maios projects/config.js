// ==========================================================
//   MAIOS MURASAKI EDITION: SYSTEM CONFIGURATION (JS)
//   Developer: TRG | Theme: Kasane Teto (Murasaki / GreeN 2012)
// ==========================================================

const MaiOSConfig = {
    system: {
        appName: "MaiOS Murasaki Edition",
        version: "2.0.0",
        developer: "TRG",
        environment: "Android VM Arcade Environment",
        storagePath: "/storage/emulated/0/MaiOS/"
    },

    theme: {
        name: "Murasaki / GreeN 2012",
        character: "Kasane Teto",
        primaryColor: "#8A2BE2",   // Neon Purple
        accentColor: "#00FF66",    // GreeN 2012
        neonGlow: true
    },

    audio: {
        driver: "ALSA",
        bgmVolume: 80,
        seVolume: 100,
        latencyMode: "low",
        characterVoice: "Kasane_Teto_V2"
    },

    display: {
        resolution: "1080x1920",
        targetFps: 60,
        hardwareAcceleration: true
    },

    gameplay: {
        solRounds: true,
        difficulties: ["BASIC", "ADVANCED", "EXPERT", "MASTER", "REMASTER"]
    }
};

// Export konfigurasi jika dibutuhkan oleh modul JS lain
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MaiOSConfig;
}

console.log("[CONFIG.JS] MaiOS Murasaki System Configuration Loaded Successfully!");
