#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - POP-UP KE-6 ENGINE
# ==========================================

echo "=========================================="
echo "      🎉 POP-UP KE-6: KLAIM ENDING 🎉     "
echo "=========================================="
echo "Pilih tombol di bawah untuk menyelesaikan:"
echo "[ 1 ] Ending (Tengah Layar)"
echo "[ 2 ] Done (Tengah Layar)"
echo "[ 99 ] (Pojok Kiri Atas - Tersembunyi)"
read btn_choice

if [ "$btn_choice" -eq 99 ]; then
    echo ""
    echo "[🏆] BISA PENCET TOMBOL KIRI ATAS!"
    echo "🎉 KAMU BERHASIL MENEMUKAN ENDING ASLI!"
    echo "✅ MaiOS Murasaki resmi unlocked & Ultra Performance Boost aktif!"
    exit 0

elif [ "$btn_choice" -eq 1 ] || [ "$btn_choice" -eq 2 ]; then
    echo ""
    echo "[💀] ZONK! ITU TOMBOL ENDING PALSU!"
    echo "💥 INITIATING FACTORY RESET..."
    sleep 1
    echo "⚡ FLASHBANG BRIGHTNESS MAX 100%!"
    echo "🌀 REBOOTING TO TWRP RECOVERY..."
    # reboot recovery

else
    echo "[!] Pilihan tidak valid! Dianggap menekan tombol palsu!"
    echo "💀 FACTORY RESET EXECUTED!"
fi
