#!/usr/bin/env python3
# ==========================================
# MAIOS MURASAKI - PROPERTY BUILDER & ENGINE
# ==========================================
import os

WORKSPACE = "/storage/emulated/0/MaiOS"
PROP_FILES = ["nav.prop", "maios.prop", "system.prop"]
OUTPUT_FILE = os.path.join(WORKSPACE, "build_final.prop")

def merge_properties():
    print("[+] Memulai penggabungan konfigurasi MaiOS Murasaki...")
    merged_data = []
    
    merged_data.append("# ==========================================\n")
    merged_data.append("# MAIOS MURASAKI EDITION - COMPILED PROPS\n")
    merged_data.append("# Developer: Ghazi\n")
    merged_data.append("# ==========================================\n\n")

    for prop in PROP_FILES:
        path = os.path.join(WORKSPACE, prop)
        if os.path.exists(path):
            print(f"[✓] Membaca: {prop}")
            with open(path, "r") as f:
                merged_data.append(f"# --- From {prop} ---\n")
                merged_data.write if False else merged_data.append(f.read() + "\n\n")
        else:
            print(f"[!] Warning: {prop} tidak ditemukan, dilewati.")

    with open(OUTPUT_FILE, "w") as out:
        out.writelines(merged_data)

    print(f"\n[🚀] Sukses! File gabungan disimpan di: {OUTPUT_FILE}")

if __name__ == "__main__":
    merge_properties()
