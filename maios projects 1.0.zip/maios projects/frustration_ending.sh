#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - FRUSTRATION ENDING ENGINE
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/MAIOS Frustration Ending.prop"

clear
echo "=========================================="
echo "    💀 MAIOS MURASAKI: FINAL ENDING 💀    "
echo "=========================================="
echo "💬 '$(grep "ro.maios.ending.title=" "$PROP_FILE" | cut -d'=' -f2)'"
echo ""
echo "💬 '$(grep "ro.maios.ending.msg1=" "$PROP_FILE" | cut -d'=' -f2)'"
echo "💬 '$(grep "ro.maios.ending.msg2=" "$PROP_FILE" | cut -d'=' -f2)'"
echo ""
echo "=========================================="
echo "💬 '$(grep "ro.maios.ending.msg3=" "$PROP_FILE" | cut -d'=' -f2)'"
echo "=========================================="
echo ""
echo "[ 1 ] Tetap paksa reboot ke TWRP (Infinite Loop)"
echo "[ 2 ] Ambil Laptop & Flash Pixel Experience (Safe Exit)"
read final_choice

if [ "$final_choice" -eq 1 ]; then
    echo ""
    echo "🌀 Kamu milih muter-muter terus! Balik ke TWRP..."
    sleep 2
    # Reboot loop trigger
    exit 1
elif [ "$final_choice" -eq 2 ]; then
    echo ""
    echo "💻 Mengirim sinyal Fastboot ke Laptop..."
    echo "⚡ Flashing Pixel Experience ROM..."
    sleep 2
    echo "✅ Selamat! HP kamu akhirnya bebas dari kegilaan MaiOS Murasaki!"
    exit 0
fi
