#!/system/bin/sh
# ==========================================
# MAIOS - ASTRODX LOG RECORDER & VERIFIER
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/astrodx_challenge.prop"
LOG_FILE="/sdcard/AstroDX/logs/last_play.log"

echo "=========================================="
echo "🔓 SCREEN UNLOCKED!"
echo "⚠️ APAKAH ANDA BISA SELSEIN LEVEL INI?"
echo "=========================================="
echo "[🎥] MaiOS System Recorder Active..."
echo "Membuka AstroDX..."

# Simulasikan sistem merekam aktivitas game
echo "Mengecek rekaman gameplay dari file .prop..."

# Logika pementasan rekaman
if grep -q "chart_id=tutorial" "$LOG_FILE" 2>/dev/null; then
    echo "❌ [REKAMAN DITOLAK] Terdeteksi memainkan Level Tutorial!"
    echo "💀 REKAMAN MENUNJUKKAN KECURANGAN! INITIATING FACTORY RESET..."
    # reset command
elif grep -q "status=CLEAR" "$LOG_FILE" 2>/dev/null; then
    echo "🎉 [REKAMAN VALID] Lagu asli berhasil diselesaikan!"
    echo "ro.maios.challenge.status=passed" >> "$PROP_FILE"
    echo "🔓 MAIOS MURASAKI FULL UNLOCKED & BOOSTED!"
else
    echo "💥 [REKAMAN GAGAL] Tidak ada lagu asli yang diselesaikan!"
    echo "💀 INITIATING FACTORY RESET..."
    # reset command
fi
