#!/system/bin/sh

# Path folder dan file target
TARGET_DIR="/mnt/sdcard/MaiOS"
CONFIG_FILE="$TARGET_DIR/config.json"

echo "=========================================="
echo "    MaiOS Murasaki - System Check         "
echo "=========================================="

# 1. Cek apakah folder MaiOS ada
if [ -d "$TARGET_DIR" ]; then
    echo "[OK] Folder $TARGET_DIR ditemukan."
else
    echo "[ERROR] Folder $TARGET_DIR tidak ditemukan!"
fi

# 2. Cek apakah file config.json ada
if [ -f "$CONFIG_FILE" ]; then
    echo "[OK] File config.json ditemukan!"
    echo "------------------------------------------"
    echo "Isi file config.json:"
    cat "$CONFIG_FILE"
    echo ""
    echo "------------------------------------------"
    echo "[SUCCESS] Verifikasi sistem MaiOS selesai!"
else
    echo "[ERROR] File config.json tidak ditemukan di $TARGET_DIR!"
fi

echo "=========================================="
