#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - INFINITE RETRY ENGINE
# ==========================================

RETRY_PROP="/storage/emulated/0/MaiOS/MAIOS Infinite Retry.prop"
BLACKOUT_PROP="/storage/emulated/0/MaiOS/MAIOS Black Out Trap.prop"
XML_FILE="/storage/emulated/0/MaiOS/strings.xml"
XML_BAK="/storage/emulated/0/MaiOS/strings.xml.bak"

attempt=1

while true; do
    clear
    echo "=========================================="
    echo "  🔄 MAIOS AUTO-RETRY SYSTEM (Attempt $attempt) "
    echo "=========================================="
    echo "HP ini telah rusak, Anda mau pilih mana?"
    echo "[ 1 ] Redownload MAIOS"
    echo "[ 2 ] Redownload MAIOS"
    read choice

    echo ""
    echo "[⚠️] $(grep "ro.maios.retry.msg_rebooting=" "$RETRY_PROP" | cut -d'=' -f2)"
    
    # 1. Efek Blackout XML
    cp "$XML_FILE" "$XML_BAK" 2>/dev/null
    rm -f "$XML_FILE"
    
    clear
    echo ".........................................."
    echo "       [ LAYAR MATI TOTAL / BLACKOUT ]    "
    echo ".........................................."
    sleep 2

    # 2. Restore XML
    cp "$XML_BAK" "$XML_FILE" 2>/dev/null
    
    # 3. Teleport TWRP & Omelan
    clear
    echo "=========================================="
    echo "💀 TWRP RECOVERY SCREEN"
    echo "=========================================="
    echo "💬 'Sana download sendiri link-nya! HP terus suruh saya, enggak jelas!'"
    echo "💬 'Mendingan pipis dulu atau kalau enggak, beneran ini enggak bisa di-download!'"
    echo "💬 'Kalau beneran dipipisin, aku katai kamu lagi!'"
    echo "=========================================="
    echo ""
    echo "❌ $(grep "ro.maios.retry.msg_fail=" "$RETRY_PROP" | cut -d'=' -f2)"
    echo "🔄 Rebooting in 3 seconds..."
    
    attempt=$((attempt + 1))
    sleep 3
done
