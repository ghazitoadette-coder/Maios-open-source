import json
import os
from datetime import datetime

def log_system(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {message}\n"
    with open("system.log", "a") as log_file:
        log_file.write(log_entry)

print("==================================================")
print("      MAIOS MURASAKI EDITION: PYTHON ENGINE       ")
print("            Core Contributor: TRG                 ")
print("==================================================")

# 1. Validasi XML
print("\n--- [1] VALIDATING VISUAL RESOURCE (XML) ---")
if os.path.exists("maios_layout.xml") and os.path.exists("colors.xml"):
    print("[XML STATUS] OK -> UI Layout & Colors Loaded!")
    log_system("[XML] Visual resources validated successfully.")
else:
    print("[XML STATUS] WARNING -> Missing layout configuration!")
    log_system("[XML WARNING] Missing visual files.")

# 2. Validasi & Baca JSON
print("\n--- [2] VALIDATING SYSTEM DATABASE (JSON) ---")
json_files = ["expert_tracks.json", "remaster_charts.json", "player_stats.json", "shop_items.json"]
for jf in json_files:
    if os.path.exists(jf):
        print(f"[JSON STATUS] OK -> {jf} detected.")
        log_system(f"[JSON] {jf} loaded successfully.")
    else:
        print(f"[JSON STATUS] MISSING -> {jf} not found!")
        log_system(f"[JSON ERROR] {jf} is missing.")

# 3. Status Audio & Sistem
print("\n--- [3] INITIALIZING SYSTEM SOUND ---")
print("[AUDIO] Character Theme : Kasane Teto")
print("[AUDIO] Status          : PYTHON ENGINE ACTIVE & READY")
log_system("[SYSTEM] MaiOS Python Engine fully operational.")

print("==================================================")
