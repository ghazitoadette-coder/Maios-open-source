#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - NO SURVIVOR ENGINE
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/tidak ada yang selamat ini.prop"

clear
echo "=========================================="
echo "   ☠️  MAIOS MURASAKI: NO SURVIVOR  ☠️    "
echo "=========================================="
echo "⚠️ SURVIVAL CHANCE: $(grep "ro.maios.survival_rate=" "$PROP_FILE" | cut -d'=' -f2)"
echo "------------------------------------------"
echo ""

# Jalankan Google TTS Menyuarakan Vonis Akhir di Background
am broadcast -a android.intent.action.TTS_SPEAK --es text "$(grep "ro.maios.tts.fatal_msg1=" "$PROP_FILE" | cut -d'=' -f2)" > /dev/null 2>&1
sleep 3

am broadcast -a android.intent.action.TTS_SPEAK --es text "$(grep "ro.maios.tts.fatal_msg2=" "$PROP_FILE" | cut -d'=' -f2)" > /dev/null 2>&1
sleep 3

am broadcast -a android.intent.action.TTS_SPEAK --es text "$(grep "ro.maios.tts.fatal_msg3=" "$PROP_FILE" | cut -d'=' -f2)" > /dev/null 2>&1
sleep 4

clear
echo "=========================================="
echo "🌀 SYSTEM PERMANENTLY LOCKED IN TWRP LOOP"
echo "=========================================="
echo "💻 Silakan hubungkan HP ke laptop untuk flashing Pixel Experience."
echo ""

# Mengunci sistem dalam loop tanpa henti
while true; do
    sleep 1
done
