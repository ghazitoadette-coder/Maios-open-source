#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - BLACKOUT & TWRP ENGINE
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/MAIOS Black Out Trap.prop"
XML_FILE="/storage/emulated/0/MaiOS/strings.xml"
XML_BAK="/storage/emulated/0/MaiOS/strings.xml.bak"

# Membaca durasi blackout dari file prop
BLACKOUT_TIME=$(grep "ro.maios.blackout.duration_seconds=" "$PROP_FILE" | cut -d'=' -f2)

while true; do
    clear
    echo "=========================================="
    echo "    ⚡ BOOTLOADER: KERNEL REBOOT TRAP ⚡  "
    echo "=========================================="
    echo "HP ini telah rusak, Anda mau pilih mana?"
    echo ""
    echo "[ 1 ] Redownload MAIOS"
    echo "[ 2 ] Redownload MAIOS"
    read choice

    echo ""
    echo "[⚠️] Tombol Redownload diklik!"
    
    # 1. Hapus sementara string XML (Efek Blackout)
    cp "$XML_FILE" "$XML_BAK" 2>/dev/null
    rm -f "$XML_FILE"
    
    # 2. Layar Mati Total
    clear
    echo ".........................................."
    echo "       [ LAYAR MATI TOTAL / BLACKOUT ]    "
    echo ".........................................."
    sleep ${BLACKOUT_TIME:-2}

    # 3. Restore kembali string XML
    cp "$XML_BAK" "$XML_FILE" 2>/dev/null
    
    # 4. Masuk ke TWRP Recovery & Omelan
    clear
    echo "=========================================="
    echo "🌀 TELEPORTING TO TWRP RECOVERY..."
    echo "=========================================="
    sleep 1
    
    echo "💀 TWRP RECOVERY SCREEN:"
    echo "------------------------------------------"
    echo "💬 '$(grep "ro.maios.twrp.rant1=" "$PROP_FILE" | cut -d'=' -f2)'"
    echo "💬 '$(grep "ro.maios.twrp.rant2=" "$PROP_FILE" | cut -d'=' -f2)'"
    echo "💬 '$(grep "ro.maios.twrp.rant3=" "$PROP_FILE" | cut -d'=' -f2)'"
    echo "------------------------------------------"
    echo ""
    echo "🔄 Auto restarting in 3 seconds back to TWRP..."
    sleep 3
done
