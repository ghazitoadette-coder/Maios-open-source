#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - SANTAI TRAP ENGINE
# ==========================================

SANTAI_PROP="/storage/emulated/0/MaiOS/MAIOS Santai.prop"
XML_FILE="/storage/emulated/0/MaiOS/strings.xml"
XML_BAK="/storage/emulated/0/MaiOS/strings.xml.bak"

clear
echo "=========================================="
echo "          ☕ MAIOS MODE SANTAI ☕          "
echo "=========================================="
echo "💬 '$(grep "ro.maios.santai.fake_easy_prompt=" "$SANTAI_PROP" | cut -d'=' -f2)'"
echo ""
echo "[ 1 ] Lanjut Santai (Aman)"
echo "[ 2 ] Keluar Santai (Aman)"
read choice

echo ""
echo "⏳ Memproses mode santai..."
sleep 2

# Tiba-tiba nge-prank: layar dimatiin (blackout) & masuk TWRP loop!
cp "$XML_FILE" "$XML_BAK" 2>/dev/null
rm -f "$XML_FILE"

clear
echo ".........................................."
echo "       [ LAYAR MATI TOTAL / BLACKOUT ]    "
echo ".........................................."
sleep 2

cp "$XML_BAK" "$XML_FILE" 2>/dev/null

clear
echo "=========================================="
echo "💀 KENA PRANK! MASUK TWRP RECOVERY LAGI!"
echo "=========================================="
echo "💬 '$(grep "ro.maios.santai.msg1=" "$SANTAI_PROP" | cut -d'=' -f2)'"
echo "💬 '$(grep "ro.maios.santai.msg2=" "$SANTAI_PROP" | cut -d'=' -f2)'"
echo "=========================================="
echo ""
echo "🔄 Muter lagi ke infinite loop..."
sleep 3
