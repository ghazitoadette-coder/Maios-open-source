#!/system/bin/sh
# ==========================================
# MAIOS MURASAKI - GOOGLE TTS BACKGROUND ENGINE
# ==========================================

PROP_FILE="/storage/emulated/0/MaiOS/MAIOS Call 110.prop"

# Ambil teks dialog dari file prop
D1=$(grep "ro.maios.tts.dialog1=" "$PROP_FILE" | cut -d'=' -f2)
D2=$(grep "ro.maios.tts.dialog2=" "$PROP_FILE" | cut -d'=' -f2)
D3=$(grep "ro.maios.tts.dialog3=" "$PROP_FILE" | cut -d'=' -f2)

# Fungsi untuk memicu Google TTS menyuarakan teks
speak_tts() {
    am broadcast -a android.intent.action.TTS_SPEAK --es text "$1" > /dev/null 2>&1
}

# Jalankan percakapan TTS berurutan di latar belakang
sleep 1
speak_tts "$D1"
sleep 4

speak_tts "$D2"
sleep 3

speak_tts "$D3"
