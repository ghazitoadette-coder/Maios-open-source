#!/bin/bash
clear
echo "[+] Launching MaiOS Murasaki Edition..."
python3 maios_engine.py
